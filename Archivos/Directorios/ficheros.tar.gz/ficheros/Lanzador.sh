#!/bin/bash

./Automatico.sh &
