#!/bin/bash

rm recibir/*
rm desencriptar/*
rm trabajar/*
rm enviar/*
